# HummusJS
[![NPM version](http://img.shields.io/npm/v/hummus.svg?style=flat)](https://www.npmjs.org/package/hummus)
[![Build Status](https://travis-ci.com/galkahana/HummusJS.svg)](https://travis-ci.com/galkahana/HummusJS)
[![Build status](https://ci.appveyor.com/api/projects/status/vfvirwg87p02hbv8?svg=true)](https://ci.appveyor.com/project/galkahana/hummusjs)
[![Donate](https://img.shields.io/badge/Donate-PayPal-green.svg)](https://www.paypal.com/cgi-bin/webscr?cmd=_donations&business=Z4A979AJEZLMC&lc=GB&item_name=PDFHummus&currency_code=USD&bn=PP%2dDonationsBF%3abtn_donate_SM%2egif%3aNonHosted)

Welcome to HummusJS.   
A Fast NodeJS Module for Creating, Parsing an Manipulating PDF Files and Streams.   
Documentation is available [here](https://github.com/galkahana/HummusJS/wiki).   
Project site is [here](http://www.pdfhummus.com).   

If you are looking for a C++ Library go [here](https://github.com/galkahana/PDF-Writer).   
